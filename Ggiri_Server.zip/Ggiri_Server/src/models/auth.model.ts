// auth.model.ts
/**
 * Implementation of Authentication Model
 * @packageDocumentation
 */

import { AuthDBConnection } from '../config/dbconnection'
import * as T from  '../types/types';
//import * as C from './customer.model';
var springedge = require('springedge');
var moment = require('moment');

const Login  = AuthDBConnection.Model.extend ({
    tableName: "login",
    hasTimestamps: ["created", "modified"],
    // customers() {
    //     return this.belongsTo( C.Customer );
    // }
});

async function loginDBOperation( input :  T.LoginAPIInputType ) : Promise<T.DBResponseType> {

    const loginAPIresponse :  T.DBResponseType = {
        status: true
    };
    // console.log( '[auth.model.ts::loginAPI] called', input);

    await  Login.forge()
                .query( ( qb ) => {
                        qb.column('id')
                        .where( 'email', '=',  input.email )
                        .where( 'password', '=',  input.password )
                        .where( 'active', '=', true )
                    }
                )
                .fetch()
                .then( ( response : any ) =>  {
                    const res = response.toJSON();

                    loginAPIresponse.id = res.id;
                    loginAPIresponse.status = true;
                    loginAPIresponse.message = 'Login Successful!';
                })
                .catch( ( error : any ) => {
                    loginAPIresponse.id = 0;
                    loginAPIresponse.status = false;
                    loginAPIresponse.message = error;
                });
    // console.log( '[auth.model.ts::loginAPI] called');
    return  loginAPIresponse;
}
async function loginmobileDBOperation( input :  T.LoginAPIInputType ) : Promise<T.DBResponseType> {

    const loginAPIresponse :  T.DBResponseType = {
        status: true
    };

    const otp = ("" + Math.random()).substring(2, 6);
    var params = {
    'sender': 'SEDEMO',
    'apikey': '6ms0gt855d4aa4q708n72m33k214568m1',
    'to': [
        '91'+input.phone  //Moblie Numbers 
    ],
    'message': `Hi, this is a ${otp} test message`,
    'format': 'json'
    };
    
    let promise = new Promise(function (resolve, reject) {
        springedge.messages.send(params, 5000, async function (err, response) {
        if (err) {
            reject(err)
            
            // loginAPIresponse.status = false
            // loginAPIresponse.message = "Failed to send OTP. Please use a valid mobile number." 
        }
        else{
            
            await  Login.forge()
                .query( ( qb ) => {
                        qb.column('id')
                        .where({'phone':input.phone})
                        .update({'otp':otp,'otp_expire_at': new Date(Date.now())})
                    }
                )
                .fetch()
                .then( ( response : any ) =>  {
                    const res = response.toJSON();
                    console.log(res)
                    // loginAPIresponse.id = res.id;
                    // loginAPIresponse.status = true;
                    // loginAPIresponse.message = 'Login Successful!';
                })
                .catch( ( error : any ) => {
                    console.log('error')
                    // loginAPIresponse.id = 0;
                    // loginAPIresponse.status = false;
                    // loginAPIresponse.message = error;
                });
            // loginAPIresponse.status = true
            // loginAPIresponse.message = "OTP sent to mobile successfully!"  
            resolve(response)
        }
        });
    }) 

   await promise.then(function (response) {
        console.log(response);
        loginAPIresponse.status = true
        loginAPIresponse.message = "OTP sent to mobile successfully!"  
    }, function (err) {
        console.log('Err');
        loginAPIresponse.status = false
        loginAPIresponse.message = "Failed to send OTP. Please use a valid mobile number." 
    });
    return loginAPIresponse
}

async function verifyOTPRouteDBOperation( input :  T.LoginAPIInputType ) : Promise<T.DBResponseType> {

    const loginAPIresponse :  T.DBResponseType = {
        status: true
    };
    // console.log( '[auth.model.ts::loginAPI] called', input);
    var minsDiff
    await  Login.forge()
                .query( ( qb ) => {
                        qb.column('id')
                        .where({'phone':input.phone, 'otp':input.otp})
                    }
                )
                .fetch()
                .then( ( response : any ) =>  {
                    const res = response.toJSON();
                    // var startDate = moment(res.otp_expire_at, 'YYYY-M-DD HH:mm:ss')
                    // var endDate = moment(new Date(Date.now()), 'YYYY-M-DD HH:mm:ss')
                    // minsDiff = endDate.diff(startDate, 'minutes')
                    loginAPIresponse.id = res.id;
                    loginAPIresponse.status = true;
                    loginAPIresponse.message = 'Otp verified successfully!';
                })
                .catch( ( error : any ) => {
                    loginAPIresponse.id = 0;
                    loginAPIresponse.status = false;
                    loginAPIresponse.message = error;
                });
    // console.log( '[auth.model.ts::loginAPI] called');
    return  loginAPIresponse;
}

async function showImgDBOperation( input : any ) : Promise<T.DBResponseType> {

    const loginAPIresponse :  T.DBResponseType = {
        status: true
    };
    console.log(input.file.hapi.filename, input.file._data.toJSON().data)
    await  Login.forge()
    .query( ( qb ) => {
            qb.column('id')
            .update({'img':input.file._data.toJSON().data})
        }
    )
    .fetch()
    .then( ( response : any ) =>  {
        const res = response.toJSON();

        loginAPIresponse.id = res.id;
        loginAPIresponse.status = true;
        loginAPIresponse.message = 'Image uploaded!';
    })
    .catch( ( error : any ) => {
        loginAPIresponse.id = 0;
        loginAPIresponse.status = false;
        loginAPIresponse.message = error;
    });
    return loginAPIresponse
}

const AuthModel: T.AuthAPIType  = {
    login: loginDBOperation,
    loginmobile: loginmobileDBOperation,
    verifyOTPRoute :verifyOTPRouteDBOperation,
    showImg: showImgDBOperation
};

export default AuthModel;