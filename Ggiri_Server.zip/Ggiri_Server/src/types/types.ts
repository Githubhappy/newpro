// types.ts 
/**
 * Definition of custom API types used in the implementation 
 * @packageDocumentation
 */

'use strict'
// Import user defined data types
import * as T from './data-types';


/**
 * Definition of AuthAPI Type
 */
export type AuthAPIType  =  {
    login: ( input : T.LoginAPIInputType ) => Promise<T.DBResponseType>;
    loginmobile: ( input : T.LoginAPIInputType ) => Promise<T.DBResponseType>;
    verifyOTPRoute: ( input : T.LoginAPIInputType ) => Promise<T.DBResponseType>;
    showImg: ( input : T.LoginAPIInputType ) => Promise<T.DBResponseType>;
};


export  *  from './data-types'