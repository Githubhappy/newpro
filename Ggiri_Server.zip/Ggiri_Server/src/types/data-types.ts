'use strict'

type LoginAPIInputType  = {
    email: string;
    password: string;
    phone:number;
    otp:string;
    file:string;
}

type DBResponseType  = {
    id?: number;
    status?: boolean;
    message?: string;
};


export  {
    LoginAPIInputType,
    DBResponseType
};