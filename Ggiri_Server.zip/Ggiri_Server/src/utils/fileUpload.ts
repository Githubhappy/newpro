import * as AWS from "aws-sdk";
import * as uuidv4 from "uuid/v4";
import * as fileSys from "fs";
import * as utilIns from "util";
//import {SunProError} from "../../../shared/types/error";
//import {UPLOAD_FAILED, ERR_014} from "../../../shared/types/error-codes-messages";

const unlinkIns = utilIns.promisify(fileSys.unlink);

AWS.config.update({
  region: "us-east-2",
  secretAccessKey: 'RVBaYwCpoI8i1Ry3rX9QNpyhxZbNh075PxBIqVff',
  accessKeyId: 'AKIATLVYRTI2XMXKANHD'
});

const albumBucketName = "ggiri.storage";//production

const s3 = new AWS.S3({
  apiVersion: "2006-03-01",
  params: { Bucket: albumBucketName }
});

let options = { partSize: 10 * 1024 * 1024, queueSize: 1 };

export default async function upload(file, fileType, htmlPath = "", name = "", pdfPath = "") {
  //console.log("Inside Upload");
  const path = "Owner_Details"
  fileType === "csv"
    ? "Csv"
    : fileType === "pdf"
      ? "GeneratedProposal" ? fileType === "txt" : "Logs"
      : "Images";

  const fileName = name ? `${path}/${name}.${fileType}` : `${path}/${uuidv4()}.${fileType}`;

  let params = {
    Bucket: albumBucketName,
    Key: fileName,
    Body: file
  };
  let fileResp = null;
  await s3
    .upload(params, options)
    .promise()
    .then(res => {
      fileResp = res;
      if (fileType === "pdf" || fileType === "txt") {
        //console.log(htmlPath);
        unlinkIns(htmlPath).catch(err => {
          //console.log("File not found, moving ahead.");
        });
        unlinkIns(pdfPath).catch(err => {
          //console.log("File not found, moving ahead.");
        });
      }
    })
    .catch(err => {
      console.log(err)
      console.error("#####")
      return Promise.reject("errror")//new SunProError(ERR_014, UPLOAD_FAILED, null))
    });
  //console.log(fileResp)
  return fileResp;
}
