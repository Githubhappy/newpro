// index.ts 
/**
 * Implementation of route initialization 
 * @packageDocumentation
 */

/**
 * TODO 
 * - Define proper error domain - revisit  SunproError 
 */

import { Server, ServerRoute, ResponseToolkit} from '@hapi/hapi';
import { compose } from 'ramda';

import authApiRoutes from  './auth.route';

const addRoute = ( server: Server ) => compose(
    ( route: ServerRoute ) => server.route( route ),
    responseHandler, 
    injectAugHandler,      
);


const injectAugHandler = (route: ServerRoute) => ({
    ...route,
    options: {
      ...route.options
    },
});

export const initRoutes = ( dataservice : any ) =>  ( server: Server ) => {
    console.log('initRoutes called');    
    [ ...authApiRoutes(dataservice) ].forEach( addRoute( server) );
    return server; 
}



// Changes route definition to use a wrapper around the real
// route handler for passing errors to the client uniformly.
export const responseHandler = ( route: ServerRoute ): ServerRoute => ( {
    ...route,
    options: {
        ...route.options,
        handler: augmentHandler( ( route.options as any ).handler ),
    }
} );

// A hacky way to tell if the response from a handler
// is a HAPI response object or one of our own.
const isHapiResponse = ( resp : any ) => (!!(resp.request && resp.settings));

// Wrap a route handler to catch promise rejects
// and package them into a uniform JSON object.
// The client code unpacks this and rejects on the client
// side (if there's an error). Non-error cases have
// data objects populated (and no error), and error
// cases have no data but error fields populated.
const augmentHandler = (handler : any ) => (request : Request , h: ResponseToolkit) =>
    handler(request, h)
        .then( (result : any ) =>
            // If we receive a HAPI response object from handler,
            // let it go untouched. Otherwise we wrap the results 
            isHapiResponse( result ) ? result : { error: undefined, data: result,}
        ).catch( ( err: Error ) => {
            console.error( err )
            return ( {
                error: err, 
                data: undefined /* No result in success case */
            } )
        });