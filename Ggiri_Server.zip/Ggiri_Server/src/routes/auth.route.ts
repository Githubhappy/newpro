import * as Joi from '@hapi/joi';
import URL from '../urls';
import * as T from '../types/types';

const WelcomeRouteHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
        const loginAPIresponse :  T.DBResponseType = {
            status: true,
            message: "Welcome to Gigiri"
        };
        console.log( 'auth.route.js::helloRouteHandler');
        return loginAPIresponse
        //return dataservice.login( request.payload ); 
    }    
}

const Welcome  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'GET',
    options: {
        handler: WelcomeRouteHandler( dataservice ),
        validate: {
        }
    },
    path: URL.WELCOME,
} );

const loginRouteHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
        console.log( 'auth.route.js::loginRouteHandler  request', request.payload );
        return dataservice.login( request.payload ); 
    }    
}

const loginRoute  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: loginRouteHandler( dataservice ),
        validate: {
            payload: {
                // email: Joi.string().email({ minDomainSegments: 2, tlds: { allow: ['com', 'net', 'in', 'org', 'co'] } }),
                // password :Joi.string().pattern(new RegExp('^[a-zA-Z0-9]{6,30}$')),
                email: Joi.string().required(),
                password :Joi.string().required(),
                repeat_password: Joi.ref( 'password' )
            }
        }
    },
    path: URL.LOGIN,
} );


const loginmobileRouteHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
        console.log( 'auth.route.js::loginRouteHandler  request', request.payload );
        return dataservice.loginmobile( request.payload ); 
    }    
}

const loginmobileRoute  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: loginmobileRouteHandler( dataservice ),
        validate: {
            payload: {
                phone: Joi.number().required(),
            }
        }
    },
    path: URL.LOGIN_MOBILE,
} );


const verifyOTPRouteHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
        console.log( 'auth.route.js::loginRouteHandler  request', request.payload );
        return dataservice.verifyOTPRoute( request.payload ); 
    }    
}

const verifyOTPRoute  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: verifyOTPRouteHandler( dataservice ),
        validate: {
            payload: {
                phone: Joi.number().required(),
                otp:Joi.number().required(),
            }
        }
    },
    path: URL.VERIFY_OTP,
} );

const showImgHandler = ( dataservice:  T.AuthAPIType )  => {
    return async  ( request : any ) =>  { 
        console.log( 'auth.route.js::showImgHandler', request.payload.file);
        let data: object = null;
        let input = request.payload;
        if (input.file && input.file.hapi.filename != '') {
            let file_name = (input.file) ? input.file.hapi.filename : '';
            let file_type1 = (file_name) ? (path.extname(file_name)).replace('.', '') : '';
            await upload(request.payload.file, file_type1).then((resp) => {
                console.log(resp.Location)
                return resp.Location;
            }).then(async (resp) => {
                //console.log("$$",resp)
                input.file = resp
                //data = (await dataservice.updatePicCustomer(input, request.headers.authorization))
            }).catch((err: any) => {
                console.log("customerFilesUploadHandler::-Err-", err)
                data = {
                    status: false,
                    message: 'Customer file not uploaded',
                    data: {}
                }
            });
        } else {
            //data =  (await dataservice.updateCustomer(input))
            data = {
                status: false,
                message: 'Customer file not uploaded or file not selected',
                data: {}
            }
        }
        //return dataservice.showImg( request.payload ); 
    }    
}

import { RouteOptionsPayload } from '@hapi/hapi';
import path = require('path');
import upload from '../utils/fileUpload';
const updateRouteOptions: RouteOptionsPayload = {
    allow: "multipart/form-data",
    maxBytes: 20 * 1000 * 1000 ,
    parse: true,
    timeout: false,
    multipart: {
    output: 'stream'
    }
    //output: "stream",
    };
const showImg  = ( dataservice:  T.AuthAPIType ) => ( {
    method: 'POST',
    options: {
        handler: showImgHandler( dataservice ),
        validate: {
                payload: Joi.object({
                    file:Joi.any().error(new Error("Please select a file.")).required(),       
                }),    
                // headers: Joi.object({
                //     authorization: Joi.string().required()
                // }).options({ allowUnknown: true })
            }
            ,payload: updateRouteOptions,
    },
    path: URL.SAVE_IMG,
} );


export default ( dataservice:  T.AuthAPIType ) => {
    return [
        loginRoute( dataservice ), 
        loginmobileRoute( dataservice ), 
        verifyOTPRoute(dataservice),
        showImg(dataservice),
        Welcome(dataservice),
    ];
};