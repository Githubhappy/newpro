/* List of all URLs
 */

'use strict'

const AuthURLs = {
    LOGIN : '/api/login',
    LOGIN_MOBILE : '/api/loginMobile',
    LOGOUT : '/api/logout',
    VERIFY_OTP :'/api/verifyOtp',
    SAVE_IMG:'/api/saveImg',
    SAVE_SHOW:'/api/showImg',
    WELCOME: '/api/welcome'
}

export default {
    ...AuthURLs,
};
